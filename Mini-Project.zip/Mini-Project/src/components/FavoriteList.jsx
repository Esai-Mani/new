import React from "react";

function Favorites({ favorites }) {
  return (
    <div style={{ padding: "20px", marginTop: "80px", color: "white" }}>
      <h2>⭐ Your Favorite Recipes</h2>
      {favorites.length === 0 ? (
        <p>No favorites added yet.</p>
      ) : (
        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            gap: "20px",
            marginTop: "15px",
          }}
        >
          {favorites.map((fav) => (
            <div
              key={fav.id}
              style={{
                backgroundColor: "#333",
                borderRadius: "8px",
                overflow: "hidden",
                width: "220px",
                color: "white",
              }}
            >
              <img
                src={fav.image}
                alt={fav.title}
                style={{
                  width: "100%",
                  height: "140px",
                  objectFit: "cover",
                }}
              />
              <div style={{ padding: "10px", textAlign: "center" }}>
                <h3 style={{ margin: "0 0 5px 0" }}>{fav.title}</h3>
                <p style={{ margin: 0, fontSize: "14px" }}>
                  Ready in {fav.readyInMinutes} mins
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default Favorites;
