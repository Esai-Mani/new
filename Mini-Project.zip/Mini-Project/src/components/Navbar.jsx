import React, { useContext } from "react";
import { Link } from "react-router-dom";
import logo from "../assets/logo.png";
import { AuthContext } from "../context/AuthContext";

function Navbar() {
  const { user, logout } = useContext(AuthContext);

  return (
    <nav
      style={{
        backgroundColor: "#66B032",
        padding: "15px",
        position: "fixed",
        top: 0,
        width: "100%",
        zIndex: 1000,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
      }}
    >
      <div style={{ display: "flex", alignItems: "center" }}>
        <img src={logo} alt="Isha Kitchen" style={{ height: "40px", marginRight: "10px" }} />
        <h1 style={{ color: "white", margin: 0 }}>Isha Kitchen</h1>
      </div>

      <div>
        <Link to="/" style={{ margin: "0 10px", color: "white", textDecoration: "none" }}>
          Home
        </Link>
        <Link to="/recipes" style={{ margin: "0 10px", color: "white", textDecoration: "none" }}>
          Recipes
        </Link>
        <Link to="/favorites" style={{ margin: "0 10px", color: "white", textDecoration: "none" }}>
          Favorites
        </Link>
      
        {!user && (
          <>
            <Link to="/login" style={{ margin: "0 10px", color: "white", textDecoration: "none" }}>
              Login
            </Link>
            <Link to="/register" style={{ margin: "0 10px", color: "white", textDecoration: "none" }}>
              Register
            </Link>
          </>
        )}

        {user && (
          <>
            <span style={{ margin: "0 10px", color: "yellow" }}>Hello, {user.username}</span>
            <button
              onClick={logout}
              style={{
                margin: "0 10px",
                backgroundColor: "#ff6600",
                border: "none",
                borderRadius: "5px",
                padding: "5px 10px",
                color: "white",
                cursor: "pointer",
              }}
            >
              Logout
            </button>
          </>
        )}
      </div>
    </nav>
  );
}

export default Navbar;
