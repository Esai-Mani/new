import React, { useState } from "react";

const ReviewSection = () => {
  const [reviews, setReviews] = useState([]);
  const [text, setText] = useState("");

  const addReview = () => {
    if (text.trim()) {
      setReviews([...reviews, text]);
      setText("");
    }
  };

  return (
    <div style={{ marginTop: "20px" }}>
      <h3>Reviews & Comments</h3>
      <textarea
        placeholder="Write your review..."
        value={text}
        onChange={(e) => setText(e.target.value)}
        style={{ width: "100%", padding: "10px", borderRadius: "5px", marginTop: "10px" }}
      />
      <button onClick={addReview} style={{ marginTop: "10px", padding: "10px", borderRadius: "5px", backgroundColor: "#ff6600", color: "#fff" }}>
        Submit
      </button>

      <ul style={{ marginTop: "15px" }}>
        {reviews.map((r, i) => (
          <li key={i} style={{ backgroundColor: "#eee", padding: "5px", marginBottom: "5px" }}>{r}</li>
        ))}
      </ul>
    </div>
  );
};

export default ReviewSection;
