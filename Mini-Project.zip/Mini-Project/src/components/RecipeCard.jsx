import React from "react";
import { useNavigate } from "react-router-dom";
import RecipeCard from "../components/RecipeCard";

function Recipes({ recipes, favorites, toggleFavorite }) {
  const navigate = useNavigate();

 
  const isLoggedIn = false; 

  const handleCommandClick = (recipe) => {
    if (!isLoggedIn) {
      
      navigate("/login");
    } else {
      navigate("/commandreview", { state: { recipe } });
    }
  };

  return (
    <div
      style={{
        marginTop: "80px",
        padding: "30px",
        color: "green",
        background: "#ccffe6",
      }}
    >
      <h2>🍲 Explore Recipes</h2>
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: "20px",
          marginTop: "15px",
        }}
      >
        {recipes.map((recipe) => (
          <RecipeCard
            key={recipe.id}
            recipe={recipe}
            isFavorite={favorites.some((fav) => fav.id === recipe.id)}
            toggleFavorite={toggleFavorite}
            onViewDetails={(rec) => navigate(`/recipe/${rec.id}`)}
            onCommand={handleCommandClick}
          />
        ))}
      </div>
    </div>
  );
}

export default Recipes;
