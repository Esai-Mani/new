import axios from "axios";

const API_URL = "https://api.spoonacular.com/recipes"; 
const API_KEY = "YOUR_API_KEY";  

export const fetchRecipes = async (query = "pasta") => {
  try {
    const response = await axios.get(
      `${API_URL}/complexSearch?query=${query}&number=10&apiKey=${API_KEY}`
    );
    return response.data.results;
  } catch (error) {
    console.error("Error fetching recipes:", error);
    return [];
  }
};


export const fetchRecipeById = async (id) => {
  try {
    const response = await axios.get(
      `${API_URL}/${id}/information?apiKey=${API_KEY}`
    );
    return response.data;
  } catch (error) {
    console.error("Error fetching recipe details:", error);
    return null;
  }
};
