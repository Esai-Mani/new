import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function Login({ setLoggedInUser }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!username || !password) {
      alert("Please enter both username and password!");
      return;
    }
    setLoggedInUser(username);  
    alert(`Logged in as ${username}`);
    navigate("/command-review");
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", minHeight: "100vh", backgroundColor:" #bbff33", color: "red", padding: "20px" }}>
      <h2>🔑 Login</h2>
      <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", width: "300px", gap: "15px" }}>
        <input type="text" placeholder="Username" value={username} onChange={e => setUsername(e.target.value)} style={{ padding: "10px", borderRadius: "5px" }} />
        <input type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} style={{ padding: "10px", borderRadius: "5px" }} />
        <button type="submit" style={{ padding: "10px", borderRadius: "5px", backgroundColor: "#ff6600", color: "white" }}>Login</button>
      </form>
      <p style={{ marginTop: "15px", color: "red" }}>Don't have an account? <a href="/register" style={{ color: "blue" }}>Register</a></p>
    </div>
  );
}

export default Login;
