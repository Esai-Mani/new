import React from "react";
import { useParams, Link } from "react-router-dom";

function RecipeDetail({ recipes }) {
  const { id } = useParams();
  const recipe = recipes.find((r) => r.id === parseInt(id));

  if (!recipe) {
    return (
      <div style={{ marginTop: "80px", textAlign: "center" }}>
        <h2>❌ Recipe not found!</h2>
        <Link to="/recipes">
          <button
            style={{
              marginTop: "20px",
              padding: "10px 20px",
              borderRadius: "8px",
              backgroundColor: "dodgerblue",
              color: "white",
              border: "none",
              cursor: "pointer",
            }}
          >
            🔙 Back to Recipes
          </button>
        </Link>
      </div>
    );
  }

  return (
    <div
      style={{
        marginTop: "80px",
        padding: "20px",
        maxWidth: "800px",
        margin: "auto",
        backgroundColor: "#fdfdfd",
        borderRadius: "12px",
        boxShadow: "0px 4px 12px rgba(0,0,0,0.2)",
      }}
    >
      <h2 style={{ color: "#B22222", marginBottom: "15px" }}>
        {recipe.title}
      </h2>

      <img
        src={recipe.image}
        alt={recipe.title}
        style={{
          width: "100%",
          height: "350px",
          objectFit: "cover",
          borderRadius: "10px",
          marginBottom: "20px",
        }}
      />

      <p>
        <b>⏱ Cooking Time:</b> {recipe.readyInMinutes} mins
      </p>
      <p>
        <b>💰 Price:</b> ₹{recipe.price}
      </p>
      <p>
        <b>📖 Description:</b> {recipe.description}
      </p>

      <h3 style={{ marginTop: "20px", color: "#333" }}>🥦 Ingredients</h3>
      <ul>
        {recipe.ingredients && recipe.ingredients.length > 0 ? (
          recipe.ingredients.map((ing, index) => <li key={index}>{ing}</li>)
        ) : (
          <p>No ingredients listed.</p>
        )}
      </ul>

      <h3 style={{ marginTop: "20px", color: "#333" }}>👩‍🍳 Cooking Procedure</h3>
      <pre
        style={{
          background: "#f2f2f2",
          padding: "15px",
          borderRadius: "8px",
          whiteSpace: "pre-wrap",
          lineHeight: "1.5",
        }}
      >
        {recipe.procedure || "No procedure available."}
      </pre>

      <Link to="/recipes">
        <button
          style={{
            marginTop: "30px",
            padding: "12px 20px",
            borderRadius: "8px",
            backgroundColor: "green",
            color: "white",
            border: "none",
            cursor: "pointer",
          }}
        >
          🔙 Back to Recipes
        </button>
      </Link>
    </div>
  );
}

export default RecipeDetail;
