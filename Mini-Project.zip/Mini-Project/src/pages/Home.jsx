import React from "react";
import { Link } from "react-router-dom";
import logo from "../assets/logo.png";

function Home() {
  return (
    <div style={{
      backgroundImage: "url('https://t3.ftcdn.net/jpg/02/97/67/70/360_F_297677001_zX7ZzRq8DObUV5IWTHAIhAae6DuiEQh4.jpg')",
      backgroundSize: "cover",
      backgroundPosition: "center",
      height: "100vh",
      color: "white",
      position: "relative"
    }}>
      <div style={{ position: "absolute", top: 0, left: 0, width: "100%", height: "100%", backgroundColor: "rgba(0,0,0,0.5)" }} />
      <div style={{
        position: "relative",
        zIndex: 2,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        height: "100%",
        textAlign: "center",
      }}>
        <img src={logo} alt="Isha Kitchen" style={{ width: "120px", marginBottom: "20px" }} />
        <h1 style={{ fontSize: "3rem", fontWeight: "bold", marginBottom: "10px" }}>Welcome to Isha Kitchen</h1>
        <p style={{ fontSize: "1.2rem", marginBottom: "20px" }}>Find and Organize Your Favorite Recipes 🍳</p>
        <Link to="/recipes" style={{
          background: "#ff9800",
          color: "white",
          padding: "12px 24px",
          borderRadius: "8px",
          fontWeight: "italic",
          fontSize: "1.2rem",
          textDecoration: "none"
        }}>Explore Recipes →</Link>
      </div>
    </div>
  );
}

export default Home;
