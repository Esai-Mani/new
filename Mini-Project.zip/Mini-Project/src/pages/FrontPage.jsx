import React from "react";
import { Link } from "react-router-dom";

function FrontPage() {
  return (
    <div style={{
      backgroundImage: 'url("https://images.unsplash.com/photo-1504674900247-0877df9cc836")',
      backgroundSize: "cover",
      backgroundPosition: "center",
      height: "100vh",
      color: "white",
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      alignItems: "center",
      textShadow: "2px 2px 8px rgba(0,0,0,0.7)"
    }}>
      <h1 style={{ fontSize: "3rem", fontWeight: "bold" }}>🍴 Welcome to Isha Kitchen</h1>
      <p style={{ marginTop: "10px", fontSize: "1.2rem" }}>Discover recipes, save favorites & enjoy cooking!</p>
      <div style={{ marginTop: "20px", display: "flex", gap: "10px" }}>
        <Link to="/login"><button style={{ backgroundColor: "#ff0000", padding: "10px 20px", borderRadius: "8px", color: "white" }}>🔑 Login</button></Link>
        <Link to="/register"><button style={{ backgroundColor: "#00cc00", padding: "10px 20px", borderRadius: "8px", color: "white" }}>📝 Register</button></Link>
      </div>
    </div>
  );
}

export default FrontPage;
