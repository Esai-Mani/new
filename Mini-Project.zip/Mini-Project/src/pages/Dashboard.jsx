import React, { useContext } from "react";
import { Link } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";

function Dashboard() {
  const { user, logout } = useContext(AuthContext);

  return (
    <div style={{ padding: "20px", marginTop: "80px", color: "white" }}>
      <h2 style={{ fontSize: "2rem" }}>📊 Dashboard</h2>
      <p>Welcome, <strong>{user?.username || "Guest"}</strong>!</p>

      <div style={{ marginTop: "20px" }}>
        <Link to="/recipes" style={{ padding: "10px 20px", marginRight: "10px", backgroundColor: "green", color: "white" }}>🍲 Browse Recipes</Link>
        <Link to="/favorites" style={{ padding: "10px 20px", backgroundColor: "blue", color: "white" }}>⭐ My Favorites</Link>
      </div>

      <button onClick={logout} style={{ marginTop: "20px", padding: "10px 20px", backgroundColor: "red", color: "white" }}>
        🚪 Logout
      </button>
    </div>
  );
}

export default Dashboard;
