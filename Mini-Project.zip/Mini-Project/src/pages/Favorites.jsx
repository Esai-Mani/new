import React from "react";

function Favorites({ favorites, toggleFavorite }) {
  return (
    <div style={{ padding: "20px", marginTop: "80px", color: "#e60039" }}>
      <h2>⭐ Your Favorite Recipes</h2>
      {favorites.length === 0 ? (
        <p>No favorites added yet.</p>
      ) : (
        <div style={{ display: "flex", flexWrap: "wrap", gap: "20px" }}>
          {favorites.map((fav) => (
            <div
              key={fav.id}
              style={{
                backgroundColor: "#ace600",
                padding: "10px",
                borderRadius: "8px",
                width: "200px",
                textAlign: "center",
              }}
            >
              <img
                src={fav.image}
                alt={fav.title}
                style={{ width: "100%", borderRadius: "8px" }}
              />
              <h3>{fav.title}</h3>
              <p>Ready in {fav.readyInMinutes} mins</p>
        
              <button
                onClick={() => toggleFavorite(fav)}
                style={{
                  fontSize: "24px",
                  border: "none",
                  background: "none",
                  cursor: "pointer",
                }}
              >
                ❤️
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default Favorites;
