import React, { useState } from "react";

function CommandReview({ loggedInUser }) {
  const user = loggedInUser || "Anonymous";
  const [review, setReview] = useState("");
  const [list, setList] = useState([]);
  const [error, setError] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!review) {
      setError("Please enter your review!");
      return;
    }
    const newItem = { id: Date.now(), user, review };
    setList([...list, newItem]);
    setReview("");
    setError("");
  };

  return (
    <div style={{ marginTop: "80px", padding: "20px", background: "#ffe0e0", color: "#ff4500", minHeight: "100vh" }}>
      <h2>💬 Reviews</h2>

      <form
        onSubmit={handleSubmit}
        style={{ display: "flex", flexDirection: "column", width: "400px", gap: "15px" }}
      >
        <textarea
          placeholder="Enter your review..."
          value={review}
          onChange={(e) => setReview(e.target.value)}
          style={{ padding: "10px", fontSize: "16px", borderRadius: "8px", border: "1px solid #ccc" }}
        />
        <button
          type="submit"
          style={{ padding: "10px", backgroundColor: "#ff4500", color: "#fff", border: "none", borderRadius: "8px", cursor: "pointer" }}
        >
          Submit
        </button>
        {error && <p style={{ color: "red" }}>{error}</p>}
      </form>

      <div style={{ marginTop: "40px" }}>
        <h3>📌 Submitted Reviews</h3>
        {list.length === 0 ? (
          <p>No reviews yet!</p>
        ) : (
          list.map((item) => (
            <div
              key={item.id}
              style={{
                border: "2px solid #ff7f50",
                borderRadius: "12px",
                margin: "15px 0",
                padding: "15px",
                backgroundColor: "#fff5f0",
                boxShadow: "2px 2px 10px rgba(0,0,0,0.1)",
                color: "#333",
              }}
            >
              <p><b>User:</b> {item.user}</p>
              <p><b>Review:</b> {item.review}</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

export default CommandReview;
