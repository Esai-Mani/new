import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function Recipes({ recipes, user, favorites, toggleFavorite }) {
  const navigate = useNavigate();
  const [clickedHearts, setClickedHearts] = useState({});

  const handleCommandClick = () => {
    if (!user) {
      navigate("/login");
    } else {
      navigate("/command-review");
    }
  };

  const handleHeartClick = (recipe) => {
    toggleFavorite(recipe); 
    setClickedHearts((prev) => ({
      ...prev,
      [recipe.id]: true, 
    }));

    
    setTimeout(() => {
      setClickedHearts((prev) => ({
        ...prev,
        [recipe.id]: false,
      }));
    }, 300);
  };

  const isFavorite = (recipeId) => {
    return favorites.some((fav) => fav.id === recipeId);
  };

  return (
    <div style={{ marginTop: "80px", padding: "20px" }}>
      <h2>🍳 Explore Recipes</h2>
      <div style={{ display: "flex", gap: "20px", flexWrap: "wrap" }}>
        {recipes.map((recipe) => (
          <div
            key={recipe.id}
            style={{
              background: "#e9b5f5",
              padding: "15px",
              borderRadius: "10px",
              width: "200px",
              textAlign: "center",
              position: "relative",
            }}
          >
          
            <span
              onClick={() => handleHeartClick(recipe)}
              style={{
                position: "absolute",
                top: "10px",
                right: "10px",
                fontSize: clickedHearts[recipe.id] ? "30px" : "24px", 
                color: isFavorite(recipe.id) ? "red" : "white",
                cursor: "pointer",
                textShadow: "1px 1px 2px black",
                userSelect: "none",
                transition: "font-size 0.3s ease", 
              }}
            >
              ❤️
            </span>

            <img
              src={recipe.image}
              alt={recipe.title}
              style={{ width: "100%", borderRadius: "8px" }}
            />
            <h3>{recipe.title}</h3>
            <p>⏱ Ready in {recipe.readyInMinutes} mins</p>

            <button
              onClick={() => navigate(`/recipes/${recipe.id}`)}
              style={{
                background: "green",
                color: "white",
                padding: "5px 10px",
                margin: "5px",
                borderRadius: "5px",
                border: "none",
                cursor: "pointer",
              }}
            >
              View Details
            </button>

            <button
              onClick={handleCommandClick}
              style={{
                background: "dodgerblue",
                color: "white",
                padding: "5px 10px",
                margin: "5px",
                borderRadius: "5px",
                border: "none",
                cursor: "pointer",
              }}
            >
              Command
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Recipes;
