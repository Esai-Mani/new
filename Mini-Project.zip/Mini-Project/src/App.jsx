import React, { useState } from "react";
import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Recipes from "./pages/Recipes";
import Favorites from "./pages/Favorites";
import Login from "./pages/login";
import Register from "./pages/Register";
import CommandReview from "./pages/CommandReview";
import RecipeDetail from "./pages/RecipeDetail";

function App() {
  const [favorites, setFavorites] = useState([]);
  const [loggedInUser, setLoggedInUser] = useState("");  

  
  const recipes = [
    {
      id: 1,
      title: "Margherita Pizza",
      image:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQqLEoGo3bHJYJEpRIaveeChxuCkXPoLk3RNg&s",
      readyInMinutes: 30,
      price: 250,
      description:
        "Classic Italian pizza with cheese, tomato sauce and basil.",
      ingredients: ["Flour", "Cheese", "Tomato Sauce", "Basil"],
      procedure:
        "1. Make dough.\n2. Spread sauce.\n3. Add cheese & basil.\n4. Bake in oven.",
    },
    {
      id: 2,
      title: "Pasta Alfredo",
      image:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSPqy9hzvU2R6-8278COnWuaoo6ZQctdaz74g&s",
      readyInMinutes: 25,
      price: 200,
      description: "Creamy pasta tossed with Alfredo sauce and Parmesan cheese.",
      ingredients: ["Pasta", "Cream", "Parmesan", "Garlic"],
      procedure:
        "1. Boil pasta.\n2. Make Alfredo sauce.\n3. Toss pasta with sauce & Parmesan.",
    },
    {
      id: 3,
      title: "Kadhi Pakora",
      image:
        "https://mytastycurry.com/wp-content/uploads/2020/06/Kadhi-pakora-1-500x500.jpg",
      readyInMinutes: 25,
      price: 180,
      description: "Tangy yogurt curry with fried pakoras.",
      ingredients: ["Yogurt", "Besan", "Water", "Salt"],
      procedure:
        "1. Whisk yogurt & besan.\n2. Fry pakoras.\n3. Cook yogurt curry.\n4. Add pakoras before serving.",
    },
    {
      id: 4,
      title: "Fruit Salad",
      image: "https://i.imgur.com/JZ01mYU.jpg",
      readyInMinutes: 20,
      price: 120,
      description: "Refreshing mix of seasonal fruits.",
      ingredients: ["Strawberries", "Grapes", "Kiwi", "Banana"],
      procedure: "1. Chop fruits.\n2. Mix with honey/lemon juice.\n3. Serve chilled.",
    },
    {
      id: 5,
      title: "Paneer Butter Masala",
      image: "https://www.mygingergarlickitchen.com/wp-content/rich-markup-images/1x1/1x1-restaurant-style-paneer-butter-masala-paneer-makhani-video-recipe.jpg",
      readyInMinutes: 45,
      price: 120,
      description: "Classic North Indian dish with soft paneer cubes in a rich, creamy tomato-butter gravy.",
       ingredients: [
    "Paneer – 200-250 g, cubed",
    "Butter – 2 tbsp",
    "Oil – 1 tbsp",
    "Onion – 1 medium, finely chopped",
    "Tomato puree – 1 cup",
    "Ginger-garlic paste – 1 tsp",
    "Cashew nuts – 8-10",
    "Cream – 2-3 tbsp",
    "Red chili powder – 1 tsp",
    "Turmeric – ½ tsp",
    "Coriander powder – 1 tsp",
    "Garam masala – ½ tsp",
    "Kasuri methi – 1 tsp",
    "Salt – to taste",
    "Sugar – ½ tsp",
    "Fresh coriander – for garnish"
  ],
  procedure: "1. Soak cashew nuts and grind into a paste.\n2. Heat butter and oil, sauté onions until golden.\n3. Add ginger-garlic paste, cook 1 min.\n4. Add tomato puree and cook until oil separates.\n5. Mix in cashew paste and spices, cook 2-3 mins.\n6. Add paneer cubes and water, simmer 5-7 mins.\n7. Add cream, garam masala, kasuri methi, and stir gently.\n8. Garnish with coriander and serve hot."
    },
    {
      id: 6,
  title: "Mutton Biryani",
  image: "https://sinfullyspicy.com/wp-content/uploads/2023/12/1200-by-1200-images-2.jpg", 
  readyInMinutes: 90,
  price: 250,
  description: "Aromatic Indian biryani with tender mutton pieces cooked with fragrant basmati rice and spices.",
  ingredients: [
    "Mutton – 500 g, cleaned and cut into pieces",
    "Basmati rice – 2 cups",
    "Onions – 2 large, thinly sliced",
    "Tomatoes – 2 medium, chopped",
    "Ginger-garlic paste – 2 tsp",
    "Yogurt – ½ cup",
    "Mint leaves – ¼ cup",
    "Coriander leaves – ¼ cup",
    "Green chilies – 2-3, slit",
    "Biryani masala – 2 tbsp",
    "Red chili powder – 1 tsp",
    "Turmeric powder – ½ tsp",
    "Ghee – 2 tbsp",
    "Oil – 2 tbsp",
    "Salt – to taste",
    "Water – as needed",
    "Saffron – a few strands soaked in warm milk (optional)"
  ],
  procedure: "1. Wash and soak basmati rice for 30 mins.\n2. Heat oil and ghee in a pan, fry onions until golden brown.\n3. Add ginger-garlic paste, sauté 1-2 mins.\n4. Add mutton, turmeric, red chili powder, and biryani masala. Cook until mutton is browned.\n5. Add chopped tomatoes, yogurt, mint, coriander, and green chilies. Cook until mutton is tender.\n6. Boil water in a separate pot, add soaked rice, cook until 70% done, then drain.\n7. Layer partially cooked rice over the mutton gravy.\n8. Sprinkle saffron milk (optional) and some fried onions on top.\n9. Cover and cook on low heat (dum) for 20-25 mins.\n10. Gently mix and serve hot with raita or salad."
    },
    {
      id: 7,
      title: "Fish Curry",
  image: "https://stewwithsaba.com/wp-content/uploads/2024/05/IMG_4409-edited-500x500.jpg?crop=1", 
  readyInMinutes: 40,
  price: 180,
  description: "Tangy and spicy fish curry cooked in coconut milk with aromatic spices.",
  ingredients: [
    "Fish – 500 g (preferably kingfish or pomfret), cleaned and cut into pieces",
    "Onions – 1 large, finely chopped",
    "Tomatoes – 2 medium, chopped",
    "Ginger-garlic paste – 1 tsp",
    "Green chilies – 2, slit",
    "Turmeric powder – ½ tsp",
    "Red chili powder – 1 tsp",
    "Coriander powder – 1 tsp",
    "Coconut milk – 1 cup",
    "Tamarind paste – 1 tsp (or small lemon-sized tamarind)",
    "Curry leaves – 8-10",
    "Mustard seeds – 1 tsp",
    "Oil – 2 tbsp",
    "Salt – to taste",
    "Fresh coriander – for garnish"
  ],
  procedure: "1. Heat oil in a pan, add mustard seeds and curry leaves.\n2. Add chopped onions and sauté until golden.\n3. Add ginger-garlic paste and green chilies, sauté 1-2 mins.\n4. Add tomatoes, turmeric, red chili, and coriander powder. Cook until oil separates.\n5. Add tamarind paste and coconut milk, bring to a gentle boil.\n6. Add fish pieces carefully, simmer for 8-10 mins until fish is cooked.\n7. Garnish with fresh coriander and serve hot with steamed rice or roti."
    },
    {
      id: 8,
      title: "Butter Chicken",
  image: "https://media.istockphoto.com/id/1411524598/photo/chicken-tikka-masala-cooked-marinated-chicken-in-spiced-curry-sauce.jpg?s=612x612&w=0&k=20&c=3JLbYigOnTQm-4exK-7uKeI3YoR0g9HxAkjxmuVmfpY=", 
  readyInMinutes: 50,
  price: 220,
  description: "Tender chicken pieces cooked in a rich, creamy tomato-butter gravy.",
  ingredients: [
    "Chicken – 500 g, boneless, cut into cubes",
    "Butter – 3 tbsp",
    "Onion – 1 large, finely chopped",
    "Tomato puree – 1 cup",
    "Ginger-garlic paste – 1 tsp",
    "Cream – ½ cup",
    "Red chili powder – 1 tsp",
    "Turmeric – ½ tsp",
    "Garam masala – ½ tsp",
    "Salt – to taste",
    "Kasuri methi – 1 tsp",
    "Sugar – ½ tsp"
  ],
  procedure: "1. Marinate chicken with salt, turmeric, and chili powder for 30 mins.\n2. Heat butter, sauté onions until golden.\n3. Add ginger-garlic paste, cook 1 min.\n4. Add tomato puree and cook until oil separates.\n5. Add chicken, cook until done.\n6. Add cream, garam masala, kasuri methi, and sugar.\n7. Simmer 5 mins and serve hot."
    },
    {
      id: 9,
        title: "Vegetable Pulao",
        image: "https://www.indianveggiedelight.com/wp-content/uploads/2019/07/veg-pulao-featured.jpg",
        readyInMinutes: 35,
        price: 150,
        description: "Fragrant basmati rice cooked with mixed vegetables and mild spices.",
        ingredients: [
          "Basmati rice – 2 cups",
          "Mixed vegetables – 1.5 cups (carrot, beans, peas, capsicum)",
          "Onion – 1 medium, sliced",
          "Ginger-garlic paste – 1 tsp",
          "Green chilies – 2, slit",
          "Cinnamon – 1 inch",
          "Cloves – 3",
          "Cardamom – 2",
          "Bay leaf – 1",
          "Ghee – 2 tbsp",
          "Oil – 1 tbsp",
          "Salt – to taste",
          "Water – 4 cups"
        ],
        procedure: "1. Wash and soak rice for 20 mins.\n2. Heat ghee and oil, sauté whole spices.\n3. Add onions, sauté until golden.\n4. Add ginger-garlic paste and green chilies, cook 1 min.\n5. Add vegetables, sauté 2-3 mins.\n6. Add soaked rice and water, salt, bring to boil.\n7. Cover and cook on low heat until rice is done.\n8. Fluff rice gently and serve hot."
      },
      
    {
      id: 10,
      title: "Dal Makhani",
      image: "https://images.slurrp.com/prod/recipe_images/transcribe/main%20course/Dal-makhini.webp?impolicy=slurrp-20210601&width=1200&height=675",
      readyInMinutes: 60,
      price: 160,
      description: "Creamy black lentils cooked slowly with butter and spices.",
      ingredients: [
        "Whole black lentils (urad dal) – 1 cup",
        "Red kidney beans (rajma) – ¼ cup",
        "Onion – 1 large, finely chopped",
        "Tomato puree – 1 cup",
        "Ginger-garlic paste – 1 tsp",
        "Green chilies – 2, chopped",
        "Butter – 3 tbsp",
        "Cream – ¼ cup",
        "Red chili powder – 1 tsp",
        "Turmeric – ½ tsp",
        "Garam masala – ½ tsp",
        "Salt – to taste",
        "Water – as needed",
        "Coriander – for garnish"
      ],
      procedure: "1. Soak lentils and kidney beans overnight. Pressure cook until soft.\n2. Heat butter, sauté onions until golden.\n3. Add ginger-garlic paste and green chilies, cook 1 min.\n4. Add tomato puree, red chili, turmeric, and salt. Cook until oil separates.\n5. Add cooked lentils and beans, simmer 20 mins.\n6. Add cream and garam masala, simmer 5 mins.\n7. Garnish with coriander and serve hot with naan or rice."
    },
  ];

  const toggleFavorite = (recipe) => {
    const exists = favorites.find((fav) => fav.id === recipe.id);
    if (exists) {
      setFavorites(favorites.filter((fav) => fav.id !== recipe.id));
    } else {
      setFavorites([...favorites, recipe]);
    }
  };

  return (
    <>
      <Navbar />
      <div style={{ paddingTop: "80px" }}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route
            path="/recipes"
            element={
              <Recipes
                recipes={recipes}
                favorites={favorites}
                toggleFavorite={toggleFavorite}
              />
            }
          />
          <Route path="/favorites" element={<Favorites favorites={favorites} />} />
          
          <Route path="/login" element={<Login setLoggedInUser={setLoggedInUser} />} />
          <Route path="/register" element={<Register />} />
         
          <Route
            path="/command-review"
            element={<CommandReview loggedInUser={loggedInUser} />}
          />
         
          <Route path="/recipes/:id" element={<RecipeDetail recipes={recipes} />} />
        </Routes>
      </div>
    </>
  );
}

export default App;
